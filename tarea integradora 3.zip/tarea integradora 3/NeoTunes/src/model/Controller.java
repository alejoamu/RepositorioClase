package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Controller {

	ArrayList<User> myUsers = new ArrayList<User>();
	ArrayList<Audio> myAudio = new ArrayList<Audio>();
	ArrayList<ReproductionList> myList = new ArrayList<ReproductionList>();

	public Controller() {

	}

	public boolean registerUserType(int year, int month, int day, String name, String urlImage, int year1, int month1,
			int day1, int userType, int type) {

		if (userType == 1) {

			myUsers.add(new Consumer(LocalDate.of(year, month, day), LocalDate.of(year1, month1, day1), type));

			return true;
		} else if (userType == 2) {

			myUsers.add(new Producer(LocalDate.of(year, month, day),name, urlImage, type));

			return true;

		}

		return false;
	}
	
	public boolean registerAudioType(String name, double duration, String album, int genre, String urlCover, double value, 
			String description, int category, String urlImage, int producerType) {
		if (producerType == 1) {
			myAudio.add(new Song(name, duration, album, genre, urlCover, value));
			return true;
		} else if (producerType == 2) {
			myAudio.add(new Podcast(name, duration, description, category, urlImage));
			return true;
		}
		return false;
	}
	public boolean registerListType(int type, String name) {
		if (type == 1) {
			myList.add(new ReproductionList(type, name)));
			return true;
		} else if (type == 2) {
			myList.add());
			return true;
		} else if (type == 3) {
			myList.add()
		}
		return false;
	}
}
