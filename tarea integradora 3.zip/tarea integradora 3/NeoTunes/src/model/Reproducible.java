package model;

public interface Reproducible {

}
