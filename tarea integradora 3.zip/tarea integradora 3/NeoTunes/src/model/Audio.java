package model;

public abstract class Audio implements Reproducible{
	private String name;
	private double duration;
	private int reproductionsNum;
	
	public Audio(String name, double duration) {
		super();
		this.name = name;
		this.duration = duration;
		
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public int getReproductionsNum() {
		return reproductionsNum;
	}

	public void setReproductionsNum(int reproductionsNum) {
		this.reproductionsNum = reproductionsNum;
	}

}
