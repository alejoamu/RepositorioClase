package model;

import java.time.LocalDate;

public class Consumer extends User {
	private LocalDate purchaseDate;
	private ConsumerType type;

	public Consumer(LocalDate vinculationDate, LocalDate purchaseDate, int type) {
		super(vinculationDate);
		this.purchaseDate = purchaseDate;
		this.type = ConsumerType.values()[type-1];
	}

	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public ConsumerType getType() {
		return type;
	}

	public void setType(ConsumerType type) {
		this.type = type;
	}
}
