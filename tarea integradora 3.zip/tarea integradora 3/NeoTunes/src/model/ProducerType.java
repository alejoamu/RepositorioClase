package model;

public enum ProducerType {
	ARTIST, CONTENT_CREATOR
}
