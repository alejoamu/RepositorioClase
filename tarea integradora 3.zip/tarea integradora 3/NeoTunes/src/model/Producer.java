package model;

import java.time.LocalDate;

public class Producer extends User {
	private String name;
	private String urlImage;
	private int acumReproductions;
	private double timeReproducer;
	private ProducerType type;
	
	
	public Producer(LocalDate vinculationDate, String name, String urlImage, int type) {
		super(vinculationDate);
		this.name = name;
		this.urlImage = urlImage;
		this.acumReproductions = 0;
		this.timeReproducer = 0;
		this.type = ProducerType.values()[type-1];
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrlImage() {
		return urlImage;
	}
	public void setUrlImage(String urlImage) {
		this.urlImage = urlImage;
	}
	public int getAcumReproductions() {
		return acumReproductions;
	}
	public void setAcumReproductions(int acumReproductions) {
		this.acumReproductions = acumReproductions;
	}
	public double getTimeReproducer() {
		return timeReproducer;
	}
	public void setTimeReproducer(double timeReproducer) {
		this.timeReproducer = timeReproducer;
	}
	public ProducerType getType() {
		return type;
	}
	public void setType(ProducerType type) {
		this.type = type;
	}
	

}
