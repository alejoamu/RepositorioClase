package model;
import java.time.LocalDate;
public class User {
	private LocalDate vinculationDate;

	public User(LocalDate vinculationDate) {
		super();
		this.vinculationDate = vinculationDate;
	}

	public LocalDate getVinculationDate() {
		return vinculationDate;
	}

	public void setVinculationDate(LocalDate vinculationDate) {
		this.vinculationDate = vinculationDate;
	}
	

}
