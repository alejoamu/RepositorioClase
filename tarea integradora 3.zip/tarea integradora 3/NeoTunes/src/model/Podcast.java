package model;

public class Podcast extends Audio{
	private String description;
	private int category;
	private String urlImage;
	
	public Podcast(String name, double duration, String description, int category, String urlImage) {
		super(name, duration);
		this.description = description;
		this.category = category;
		this.urlImage = urlImage;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public String getUrlImage() {
		return urlImage;
	}
	public void setUrlImage(String urlImage) {
		this.urlImage = urlImage;
	}
	
	
}
