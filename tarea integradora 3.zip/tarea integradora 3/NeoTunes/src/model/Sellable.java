package model;

public interface Sellable {

}
