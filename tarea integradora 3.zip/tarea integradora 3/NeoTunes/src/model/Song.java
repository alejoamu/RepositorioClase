package model;

public class Song extends Audio implements Sellable{
	private String album;
	private int genre;
	private String urlCover;
	private double value;
	private int soldNum;
	public Song(String name, double duration, String album, int genre, String urlCover, double value) {
		super(name, duration);
		this.album = album;
		this.genre = genre;
		this.urlCover = urlCover;
		this.value = value;
	}
	public String getAlbum() {
		return album;
	}
	public void setAlbum(String album) {
		this.album = album;
	}
	public int getGenre() {
		return genre;
	}
	public void setGenre(int genre) {
		this.genre = genre;
	}
	public String getUrlCover() {
		return urlCover;
	}
	public void setUrlCover(String urlCover) {
		this.urlCover = urlCover;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
	public int getSoldNum() {
		return soldNum;
	}
	public void setSoldNum(int soldNum) {
		this.soldNum = soldNum;
	}

}
