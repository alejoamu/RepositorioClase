package model;

public enum ConsumerType {
	ESTANDAR, PREMIUM
}
