package ui;

import java.util.Scanner;

import model.Controller;

public class Manager {
	private Scanner sc;
	private Controller Controller;

	public Manager() {
		this.sc = new Scanner(System.in);
		this.Controller = new Controller();
	}

	public void menu() {

		boolean exit = false;

		System.out.println("Welcome to NeoTunes");
		while (!exit) {
			System.out.println("chosse a option");
			System.out.println("1. register a user, 2. register a Audio");
			int option = sc.nextInt();
			switch (option) {
			case 1:
				registerUsers();
			case 2:
				registerAudio();
			case 3:
				registerReproductionList();
			}
		}
	}

	public static void main(String[] args) {
		Manager m = new Manager();
		m.menu();
	}

	public void executeOperation(int operation) {

		switch (operation) {
		case 0:
			System.out.println("Thanks for using our services!");
			break;
		case 1:
			registerUsers();
			break;
		default:
			System.out.println("Error, type a valid option");

		}

	}

	public void registerUsers() {
		System.out.println("choose a type of user");
		System.out.println("1. Consumer, 2. Producer");

		int userType = sc.nextInt();
		if (userType == 1) {
			System.out.println("Type the vinculation date (YYYY-MM-DD): ");
			String vinculationdate = sc.nextLine();

			int year = Integer.parseInt(vinculationdate.split("-")[0]);
			int month = Integer.parseInt(vinculationdate.split("-")[1]);
			int day = Integer.parseInt(vinculationdate.split("-")[2]);

			System.out.println("Type the purchase date (YYYY-MM-DD): ");
			String purchasedate = sc.nextLine();

			int year1 = Integer.parseInt(purchasedate.split("-")[0]);
			int month1 = Integer.parseInt(purchasedate.split("-")[1]);
			int day1 = Integer.parseInt(purchasedate.split("-")[2]);
			System.out.println("choose the type of consumer");
			System.out.println("1 for standar, 2 for premium");
			int type = sc.nextInt();

			if (Controller.registerUserType(year, month, day, null, null, year1, month1, day1, userType, type)) {

				System.out.println("User consumer registered successfully");

			} else {

				System.out.println("Error, user consumer couldn't be registered");
			}
		} else if (userType == 2) {
			System.out.println("Type the vinculation date (YYYY-MM-DD): ");
			String date = sc.nextLine();
			int year = Integer.parseInt(date.split("-")[0]);
			int month = Integer.parseInt(date.split("-")[1]);
			int day = Integer.parseInt(date.split("-")[2]);

			System.out.println("type the name");
			String name = sc.nextLine();
			System.out.println("type the url image");
			String urlImage = sc.nextLine();
			System.out.println("choose the type of productor");
			System.out.println("1 for artist, 2 for content creator");
			int type = sc.nextInt();

			if (Controller.registerUserType(year, month, day, name, urlImage, 0, 0, 0, userType, type)) {

				System.out.println("User premium registered successfully");

			} else {

				System.out.println("Error, User premium couldn't be registered");
			}
		}
	}

	public void registerAudio() {
		System.out.println("what type of producer are you?");
		System.out.println("1. Artist, 2. Content Creator");
		int producerType = sc.nextInt();
		sc.nextLine();
		if (producerType == 1) {
			System.out.println("type the name of the song");
			String name = sc.nextLine();
			System.out.println("type the song  duration in seconds");
			double duration = sc.nextDouble();
			System.out.println("type the album of the song");
			String album = sc.nextLine();
			System.out.println("choose the genre of the song");
			System.out.println("1. Rock, 2.Pop, 3.Trap, 4.House");
			int genre = sc.nextInt();
			sc.nextLine();
			System.out.println("type the url Cover");
			String urlCover = sc.nextLine();
			System.out.println("type the song value in dolars");
			double value = sc.nextDouble();
			if (Controller.registerAudioType(name, duration, album, genre, urlCover, value, null, 0, null,
					producerType)) {

				System.out.println("Song registered successfully");

			} else {

				System.out.println("Error, Song couldn't be registered");
			}
		} else if (producerType == 2) {
			System.out.println("type the name of the spodcast");
			String name = sc.nextLine();
			System.out.println("type the song  duration in seconds");
			double duration = sc.nextDouble();
			sc.nextLine();
			System.out.println("type the album of the description");
			String description = sc.nextLine();
			System.out.println("choose the category of the podcast");
			System.out.println("1. Politics, 2. Entertainment, 3. Videogame, 4. Fashion");
			int category = sc.nextInt();
			sc.nextLine();
			System.out.println("type the url image");
			String urlImage = sc.nextLine();
			if (Controller.registerAudioType(name, duration, null, 0, null, 0, description, category, urlImage,
					producerType)) {

				System.out.println("Podcast registered successfully");

			} else {

				System.out.println("Error, Podcast couldn't be registered");
			}
		}
	}

	public void registerReproductionList() {

		System.out.println("what type of user are you?");
		System.out.println("1. consumer, 2. producer");
		int userType = sc.nextInt();
		sc.nextLine();

		if (userType == 1) {
			System.out.println("type your userName");
			int userName = sc.nextInt();
			String user = userType(userName);

			if (user.equals("ESTANDAR")) {
				System.out.print("do you have # cuantity of list");
				int quantityList = 10;

				if (quantityList < 20) {
					System.out.println("what type of list do you want to create?");
					System.out.println("1. Just songs, 2. Just podcast, 3. Songs and podcast");
					int ListType = sc.nextInt();

					if (ListType == 1) {
						System.out.println("Songs list");
						System.out.println("Type the name of the list");
						String listName = sc.nextLine();
					} else if (ListType == 2) {
						System.out.println("Podcast list");
						System.out.println("Type the name of the list");
						String listName = sc.nextLine();
					} else if (ListType == 3) {
						System.out.println("Songs and podcast list");
						System.out.println("Type the name of the list");
						String listName = sc.nextLine();
					}
				} else {
					System.out.println("you can´t to add more reproductions list");
				}

			} else if (user.equals("PREMIUM")) {
				System.out.println("what type of list do you want to create?");
				System.out.println("1. Just songs, 2. Just podcast, 3. Songs and podcast");
				int ListType = sc.nextInt();

				if (ListType == 1) {
					System.out.println("Songs list");
					System.out.println("Type the name of the list");
					String listName = sc.nextLine();
				} else if (ListType == 2) {
					System.out.println("Podcastlist");
					System.out.println("Type the name of the list");
					String listName = sc.nextLine();
				} else if (ListType == 3) {
					System.out.println("Songs and podcast list");
					System.out.println("Type the name of the list");
					String listName = sc.nextLine();
				}
			}

		} else if (userType == 2) {
			System.out.println("what type of producer are you?");
			System.out.println("1. Artist, 2. Content Creator");
			int producerType = sc.nextInt();
			sc.nextLine();
			if (producerType == 1) {
				System.out.println("Songs list");
				System.out.println("Type the name  of the List");
				String listName = sc.nextLine();
			} else if (producerType == 2) {
				System.out.println("Podcast list");
				System.out.println("Type the name  of the List");
				String listName = sc.nextLine();
			}
		}
	}

	public void userType(String userName) {

	}
}
