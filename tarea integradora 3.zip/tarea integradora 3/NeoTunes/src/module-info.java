/**
 * 
 */
/**
 * @author firer
 *
 */
module NeoTunes {
}