package ui;

import java.util.Scanner;

import model.Controller;

public class Manager {
	private Scanner sc;
	private Controller Controller;

	public Manager() {
		this.sc = new Scanner(System.in);
		this.Controller = new Controller();
	}

	public void menu() {

		boolean exit = false;

		System.out.println("Welcome to NeoTunes");
		while (!exit) {
			System.out.println("chosse a option");
			System.out.println("1. register a user, 2. register a Audio, 3. create a reproductionList, 4.  edit List");
			int option = sc.nextInt();
			switch (option) {
			case 1:
				registerUsers();
				break;
			case 2:
				registerAudio();
				break;
			case 3:
				registerReproductionList();
				break;
			/*
			 * case 4: showList(); break;
			 */
			case 5:
				editPlayListName();
				break;
			case 6:
				shareList();
				break;
			case 7:
				purchaseAsong();
			}
		}
	}

	public static void main(String[] args) {
		Manager m = new Manager();
		m.menu();
	}

	public void executeOperation(int operation) {

		switch (operation) {
		case 0:
			System.out.println("Thanks for using our services!");
			break;
		case 1:
			registerUsers();
			break;
		default:
			System.out.println("Error, type a valid option");

		}

	}

	public void registerUsers() {
		System.out.println("choose a type of user");
		System.out.println("1. Consumer, 2. Producer");

		int userType = sc.nextInt();
		sc.nextLine();
		if (userType == 1) {
			System.out.println("Type the vinculation date (YYYY-MM-DD): ");
			String vinculationdate = sc.nextLine();

			int year = Integer.parseInt(vinculationdate.split("-")[0]);
			int month = Integer.parseInt(vinculationdate.split("-")[1]);
			int day = Integer.parseInt(vinculationdate.split("-")[2]);

			System.out.println("type the name");
			String name = sc.nextLine();
			System.out.println("choose the type of consumer");
			System.out.println("1 for standar, 2 for premium");
			int type = sc.nextInt();

			if (Controller.registerUserType(year, month, day, name, null, userType, type)) {

				System.out.println("User consumer registered successfully");

			} else {

				System.out.println("Error, user consumer couldn't be registered");
			}
		} else if (userType == 2) {
			System.out.println("Type the vinculation date (YYYY-MM-DD): ");
			String date = sc.nextLine();
			int year = Integer.parseInt(date.split("-")[0]);
			int month = Integer.parseInt(date.split("-")[1]);
			int day = Integer.parseInt(date.split("-")[2]);

			System.out.println("type the name");
			String name = sc.nextLine();
			System.out.println("type the url image");
			String urlImage = sc.nextLine();
			System.out.println("choose the type of productor");
			System.out.println("1 for artist, 2 for content creator");
			int type = sc.nextInt();

			if (Controller.registerUserType(year, month, day, name, urlImage, userType, type)) {

				System.out.println("User premium registered successfully");

			} else {

				System.out.println("Error, User premium couldn't be registered");
			}
		}
	}

	public void registerAudio() {
		System.out.println("what type of producer are you?");
		System.out.println("1. Artist, 2. Content Creator");
		int producerType = sc.nextInt();
		sc.nextLine();
		if (producerType == 1) {
			showUsersProdu();
			System.out.println("type the index of the artist");
			int userId = sc.nextInt() - 1;
			sc.nextLine();
			System.out.println("type the name of the song");
			String name = sc.nextLine();
			System.out.println("type the song  duration in seconds");
			double duration = sc.nextDouble();
			System.out.println("type the album of the song");
			String album = sc.nextLine();
			System.out.println("choose the genre of the song");
			System.out.println("1. Rock, 2.Pop, 3.Trap, 4.House");
			int genre = sc.nextInt();
			sc.nextLine();
			System.out.println("type the url Cover");
			String urlCover = sc.nextLine();
			System.out.println("type the song value in dolars");
			double value = sc.nextDouble();
			if (Controller.registerAudioType(userId, name, duration, album, genre, urlCover, value, null, 0, null,
					producerType)) {

				System.out.println("Song registered successfully");

			} else {

				System.out.println("Error, Song couldn't be registered");
			}
		} else if (producerType == 2) {
			showUsersProdu();
			System.out.println("type the index of the creator content");
			int userId = sc.nextInt();
			sc.nextLine();
			System.out.println("type the name of the podcast");
			String name = sc.nextLine();
			System.out.println("type the song  duration in seconds");
			double duration = sc.nextDouble();
			sc.nextLine();
			System.out.println("type the album of the description");
			String description = sc.nextLine();
			System.out.println("choose the category of the podcast");
			System.out.println("1. Politics, 2. Entertainment, 3. Videogame, 4. Fashion");
			int category = sc.nextInt();
			sc.nextLine();
			System.out.println("type the url image");
			String urlImage = sc.nextLine();
			if (Controller.registerAudioType(userId, name, duration, null, 0, null, 0, description, category, urlImage,
					producerType)) {

				System.out.println("Podcast registered successfully");

			} else {

				System.out.println("Error, Podcast couldn't be registered");
			}
		}
	}

	public void registerReproductionList() {
		showUsersConsu();

		System.out.println("type the index of  the user to add a playList");
		int userid = sc.nextInt() - 1;
		System.out.println("type of the list");
		System.out.println("1. songs, 2. podcasts, 3. songs and podcast");
		int ListType = sc.nextInt();
		sc.nextLine();
		System.out.println("type the name of the playList");
		String ListName = sc.nextLine();
		System.out.println(Controller.registerList(userid, ListType, ListName));

	}

	public void editList() {
		showUsersConsu();

		System.out.println("type the index of the user to edit a playList");
		int userId = sc.nextInt();
		System.out.println(Controller.showPlayList(userId - 1));
		System.out.println("type the index of the playlist to edit a playList");
		int listIndex = sc.nextInt();
		System.out.println(Controller.showPlayList(listIndex - 1));
		System.out.println("what do you want to edit?");
		System.out.println("1. add audio, 2. Delete audio");
		int editOp = sc.nextInt();
		System.out.println(Controller.editPlayList(userId - 1, listIndex - 1, editOp));

	}

	public void editPlayListName() {
		showUsersConsu();
		System.out.println("type the index of the user to edit a playlist");
		int idConsumer = sc.nextInt() - 1;
		sc.nextLine();
		System.out.println("type the name of the playlist to edit");
		String namePlaylist = sc.nextLine();
		System.out.println("type the new name of the playlist");
		String newNamePlaylist = sc.nextLine();
		System.out.println(Controller.editNamePlaylist(idConsumer, namePlaylist, newNamePlaylist));

	}

	public void shareList() {
		showUsersConsu();
		System.out.println("type the index of the user to share a playList");
		int userId = sc.nextInt();
		System.out.println(Controller.showPlayList(userId - 1));
		System.out.println("type the index of the playlist to share ");
		int listIndex = sc.nextInt();
		System.out.println(Controller.showPlayList(listIndex - 1));
	}

	public void reproduceASong() {
		showUsersConsu();
		System.out.println("type the index of the user to play a playList");
		int userId = sc.nextInt();
		System.out.println(Controller.showSongs(userId - 1));
		System.out.println("type the index of the playlist to play a song ");
		int listIndex = sc.nextInt();
		System.out.println(Controller.showSongs(listIndex - 1));
		System.out.println("type the index of the song to play ");
		int songIndex = sc.nextInt();
		System.out.println(Controller.PlayAudio(userId-1, listIndex-1, songIndex - 1));
	}

	public void purchaseAsong() {
		showUsersProdu();
		System.out.println("input the index of the artist ");
		int userId = sc.nextInt() - 1;
		System.out.println(Controller.showSongs(userId));
		System.out.println("input the index of the song that do you want to pay");
		int songId = sc.nextInt() - 1;
		System.out.println(Controller.showSongs(songId));

	}

	public void showUsersConsu() {
		System.out.println(Controller.showUsersConsumer());
	}

	public void showUsersProdu() {
		System.out.println(Controller.showUsersProducer());
	}

}
