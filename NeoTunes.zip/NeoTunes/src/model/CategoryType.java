package model;

public enum CategoryType {
	POLITICS, ENTERTAINMENT, VIDEOGAME, FASHION
}
