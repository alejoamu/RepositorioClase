package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

public class Premium extends Consumer {
	ArrayList<ReproductionList> reproductionLists = new ArrayList<ReproductionList>();
	ArrayList<Song> purchasedSongs = new ArrayList<Song>();

	public Premium(LocalDate vinculationDate, String name) {
		super(vinculationDate, name);
		this.reproductionLists = new ArrayList<ReproductionList>();
		this.purchasedSongs = new ArrayList<Song>();
	}

	public ArrayList<ReproductionList> getMyPremiumList() {
		return reproductionLists;
	}

	public void setMyPremiumList(ArrayList<ReproductionList> myPremiumList) {
		this.reproductionLists = myPremiumList;
	}

	public ArrayList<Song> getMyPremiumSongs() {
		return purchasedSongs;
	}

	public void setMyPremiumSongs(ArrayList<Song> myPremiumSongs) {
		this.purchasedSongs = myPremiumSongs;
	}

	public boolean addPremiumList(int ListType, String ListName) {
		reproductionLists.add(new ReproductionList(ListType, ListName));
		return true;
	}

	@Override
	public String toString() {
		return this.getName();
	}

	@Override
	public String showlist() {
		String msg = "";

		for (int i = 0; i < reproductionLists.size(); i++) {
			msg += (i + 1) + "." + reproductionLists.get(i).getName()+"\n";

		}

		return msg;
	}
	@Override
	public String showSongs() {
		String msg = "";

		for (int i = 0; i < reproductionLists.size(); i++) {
			msg += (i + 1) + "." + reproductionLists.get(i).getAudioList()+"\n";
		}

		return msg;
	}

}
