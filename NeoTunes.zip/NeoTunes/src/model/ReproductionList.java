package model;

import java.util.ArrayList;

public class ReproductionList {
	private ListType type;
	private String name;
	ArrayList<Audio> audioList = new ArrayList<Audio>();
	private int[][] codeMatrix;
	private String code;
	
	public ReproductionList(int type, String name) {
		super();
		this.type = ListType.values()[type-1];
		this.name = name;
	}

	public ListType getType() {
		return type;
	}

	public void setType(ListType type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Audio> getAudioList() {
		return audioList;
	}

	public void setAudioList(ArrayList<Audio> audioList) {
		this.audioList = audioList;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	

}
