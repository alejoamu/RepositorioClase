package model;

import java.time.LocalDate;

public abstract class Consumer extends User {
	private LocalDate purshasedDate;
	private int timeAcum;
	private String genreMostListened;
	private String categoryMostListened;
	private String artistMonstListened;
	private String creatorMonstListened;

	public Consumer(LocalDate vinculationDate, String name) {
		super(vinculationDate, name);
	}

	public LocalDate getPurshasedDate() {
		return purshasedDate;
	}

	public void setPurshasedDate(LocalDate purshasedDate) {
		this.purshasedDate = purshasedDate;
	}

	public int getTimeAcum() {
		return timeAcum;
	}

	public void setTimeAcum(int timeAcum) {
		this.timeAcum = timeAcum;
	}

	public String getGenreMostListened() {
		return genreMostListened;
	}

	public void setGenreMostListened(String genreMostListened) {
		this.genreMostListened = genreMostListened;
	}

	public String getCategoryMostListened() {
		return categoryMostListened;
	}

	public void setCategoryMostListened(String categoryMostListened) {
		this.categoryMostListened = categoryMostListened;
	}

	public String getArtistMonstListened() {
		return artistMonstListened;
	}

	public void setArtistMonstListened(String artistMonstListened) {
		this.artistMonstListened = artistMonstListened;
	}

	public String getCreatorMonstListened() {
		return creatorMonstListened;
	}

	public void setCreatorMonstListened(String creatorMonstListened) {
		this.creatorMonstListened = creatorMonstListened;
	}

	public String showlist() {

		return null;

	}

	public String play() {
		return null;
	}

	public String showSongs() {
		return null;
	}

	@Override
	public String toString() {
		return this.getName();
	}

}
