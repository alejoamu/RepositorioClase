package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class User {
	private LocalDate vinculationDate;
	private String name;

	public User(LocalDate vinculationDate, String name) {
		super();
		this.vinculationDate = vinculationDate;
		this.name = name;
	}

	public LocalDate getVinculationDate() {
		return vinculationDate;
	}

	public void setVinculationDate(LocalDate vinculationDate) {
		this.vinculationDate = vinculationDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "User: " + getName() + "";
	}
	
	

}
