package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Artist extends Producer {
	ArrayList<Audio> mySong = new ArrayList<Audio>();
	
	public Artist(LocalDate vinculationDate, String name, String urlImage) {
		super(vinculationDate, name, urlImage);
		this.mySong = new ArrayList<Audio>();
	}
	
	public ArrayList<Audio> getMySong() {
		return mySong;
	}
	public void setMySong(ArrayList<Audio> mySong) {
		this.mySong = mySong;
	}
	
	public boolean addSong(String name, double duration, String album, int genre, String urlCover, double value) {
		mySong.add(new Song(name, duration, album, genre, urlCover, value));
		return true;
	}
	public String showSongs() {
		String msg = "";

		for (int i = 0; i < mySong.size(); i++) {
			msg += (i + 1) + "." + mySong.get(i).getName()+"\n";
		}

		return msg;
	}
}
