package model;

import java.time.LocalDate;
import java.util.Arrays;

public class Estandar extends Consumer {
	private ReproductionList[] reproductionLists;
	private Song[] purchasedSongs;

	public Estandar(LocalDate vinculationDate, String name) {
		super(vinculationDate, name);
		this.reproductionLists = new ReproductionList[20];
		this.purchasedSongs = new Song[100];
	}

	public ReproductionList[] getReproductionlist() {
		return reproductionLists;
	}

	public void setReproductionlist(ReproductionList[] reproductionlist) {
		this.reproductionLists = reproductionlist;
	}

	public Song[] getPurchasedsongs() {
		return purchasedSongs;
	}

	public void setPurchasedsongs(Song[] purchasedsongs) {
		this.purchasedSongs = purchasedsongs;
	}

	public boolean addEstandarList(ReproductionList newList) {
		for (int i = 0; i < reproductionLists.length; i++) {
			if (reproductionLists[i] == null) {
				reproductionLists[i] = newList;
				return true;
			}
		}
		return false;
	}

	/*public boolean shareEstandarList(int listIndex) {
		for (int i = 0; i<reproductionLists.length; i++) {
			if (reproductionLists[i]==reproductionLists[listIndex]) {
				myUsers()
				for(int j =0; reproductionLists[i].lenght; j++) {
					
				}
			}
		}
	}

	public String play(int listIndex, int audioId) {
		for (int i = 0; i < reproductionLists.length; i++) {

		}
	}*/

	/*public boolean addPurchasedsong(Song newSong) {
		for (int i = 0; i < purchasedSongs.length; i++) {
			if (purchasedSongs[i] == null) {
				purchasedSongs[i] = newSong;
				return true;
			}
		}
		return false;
	}*/

	@Override
	public String showlist() {
		String msg = "";

		for (int i = 0; i < reproductionLists.length; i++) {
			if (reproductionLists[i] != null) {
				msg += (i + 1) + "." + reproductionLists[i].getName() + "\n";
			}
		}

		return msg;
	}

	@Override
	public String showSongs() {
		String msg = "";

		for (int i = 0; i < reproductionLists.length; i++) {
			if (reproductionLists[i] != null) {
				msg += (i + 1) + "." + reproductionLists[i].getAudioList() + "\n";
			}
		}

		return msg;
	}

	@Override
	public String toString() {
		return this.getName();
	}

}
