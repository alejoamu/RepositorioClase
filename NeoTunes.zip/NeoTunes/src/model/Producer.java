package model;

import java.time.LocalDate;
import java.util.ArrayList;

public abstract class Producer extends User {
	private String urlImage;
	private int acumReproductions;
	private double timeReproducer;
	ArrayList<Audio> myAudio = new ArrayList<Audio>();
	
	public Producer(LocalDate vinculationDate, String name, String urlImage) {
		super(vinculationDate, name);
		this.urlImage = urlImage;
		this.acumReproductions = 0;
		this.timeReproducer = 0;
	}
	
	public String getUrlImage() {
		return urlImage;
	}
	public void setUrlImage(String urlImage) {
		this.urlImage = urlImage;
	}
	public int getAcumReproductions() {
		return acumReproductions;
	}
	public void setAcumReproductions(int acumReproductions) {
		this.acumReproductions = acumReproductions;
	}
	public double getTimeReproducer() {
		return timeReproducer;
	}
	public void setTimeReproducer(double timeReproducer) {
		this.timeReproducer = timeReproducer;
	}
	
	
	public String showSongs() {
		return null;
	}
}
