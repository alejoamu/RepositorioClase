package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class CreatorContent extends Producer {
	ArrayList<Audio> myPodcast = new ArrayList<Audio>();
	
	public CreatorContent(LocalDate vinculationDate, String name, String urlImage) {
		super(vinculationDate, name, urlImage);
		this.myPodcast = new ArrayList<Audio>();
	}

	public ArrayList<Audio> getMyPodcast() {
		return myPodcast;
	}

	public void setMyPodcast(ArrayList<Audio> myPodcast) {
		this.myPodcast = myPodcast;
	}
	
	public boolean addPodcast(String name, double duration, String description, int category, String urlImage) {
		myPodcast.add(new Podcast(name, duration, description, category, urlImage));
		return true;
	}
	public String showPodcast() {
		String msg = "";

		for (int i = 0; i < myPodcast.size(); i++) {
			msg += (i + 1) + "." + myPodcast.get(i).getName()+"\n";
		}

		return msg;
	}
}
