package model;

public enum GenreType {
	ROCK, POP, TRAP, HOUSE
}
