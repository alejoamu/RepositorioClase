package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Controller {

	ArrayList<User> myUsers = new ArrayList<User>();
	ArrayList<ReproductionList> myList = new ArrayList<ReproductionList>();

	public Controller() {
	}

	public boolean registerUserType(int year, int month, int day, String name, String urlImage, int userType,
			int type) {

		if (userType == 1) {
			if (type == 1) {
				myUsers.add(new Estandar(LocalDate.of(year, month, day), name));
				return true;
			} else if (type == 2) {
				myUsers.add(new Premium(LocalDate.of(year, month, day), name));
				return true;
			}
		} else if (userType == 2) {
			if (type == 1) {
				myUsers.add(new Artist(LocalDate.of(year, month, day), name, urlImage));
				return true;
			} else if (type == 2) {
				myUsers.add(new CreatorContent(LocalDate.of(year, month, day), name, urlImage));
				return true;
			}
		}

		return false;
	}

	public boolean registerAudioType(int userId, String name, double duration, String album, int genre, String urlCover,
			double value, String description, int category, String urlImage, int producerType) {
		if (!myUsers.isEmpty()) {

			if (myUsers.get(userId) != null) {
				if (myUsers.get(userId) instanceof Producer) {
					if (myUsers.get(userId) instanceof Artist) {
						((Artist) myUsers.get(userId)).addSong(name, duration, album, genre, urlCover, value);
					} else if (myUsers.get(userId) instanceof CreatorContent) {
						((CreatorContent) myUsers.get(userId)).addPodcast(name, duration, description, category,
								urlImage);
					}
					return true;
				}
			}
		}
		return false;
	}

	public String registerList(int userid, int ListType, String ListName) {
		String msg = "";
		if (!myUsers.isEmpty()) {

			if (myUsers.get(userid) != null) {
				if (myUsers.get(userid) instanceof Consumer) {
					if (myUsers.get(userid) instanceof Estandar) {
						((Estandar) myUsers.get(userid)).addEstandarList(new ReproductionList(ListType, ListName));
					} else if (myUsers.get(userid) instanceof Premium) {
						((Premium) myUsers.get(userid)).addPremiumList(ListType, ListName);
					}
					msg += "the list is registered succesfully";
					return msg;
				}
			}
		}
		msg += "error";
		return msg;
	}

	public String showUsersConsumer() {
		String msg = "";
		for (int i = 0; i < myUsers.size(); i++) {
			if (myUsers.get(i) instanceof Consumer) {
				msg += (i + 1) + ". " + myUsers.get(i).toString() + "\n";
			}
		}
		return msg;
	}

	public String showUsersProducer() {
		String msg = "";
		for (int i = 0; i < myUsers.size(); i++) {
			if (myUsers.get(i) instanceof Producer) {
				msg += (i + 1) + ". " + myUsers.get(i).toString() + "\n";
			}
		}
		return msg;
	}

	public String showPlayList(int userId) {
		String msg = "";
		if (!myUsers.isEmpty()) {
			if (myUsers.get(userId) != null) {
				if (myUsers.get(userId) instanceof Estandar) {
					msg = ((Estandar) myUsers.get(userId)).showlist();
				} else if (myUsers.get(userId) instanceof Premium) {
					msg = ((Premium) myUsers.get(userId)).showlist();
				}
			}
		}
		return msg;
	}

	public String showSongs(int userId) {
		String msg = "";
		if (!myUsers.isEmpty()) {
			if (myUsers.get(userId) != null) {
				if (myUsers.get(userId) instanceof Consumer) {
					if (myUsers.get(userId) instanceof Estandar) {
						msg = ((Estandar) myUsers.get(userId)).showSongs();
					} else if (myUsers.get(userId) instanceof Premium) {
						msg = ((Premium) myUsers.get(userId)).showSongs();
					}
				} else if (myUsers.get(userId) instanceof Producer) {
					if (myUsers.get(userId) instanceof Artist) {
						msg = ((Artist) myUsers.get(userId)).showSongs();
					}
				}
			}
		}
		return msg;

	}

	public String editPlayList(int userId, int listIndex, int editOp) {
		String msg = "Cambio realizado exitosamente";
		User objU = searchUser(userId);
		Audio objA = searchAudio(listIndex);
		Estandar usr = (Estandar) myUsers.get(userId);
		ReproductionList rl = usr.getReproductionlist()[listIndex];

		String msg = showPlayList(userId);
		if (editOp == 2) {
			if (objU instanceof Estandar) {
				Estandar objUser = (Estandar) searchUser(userId);
				for (ReproductionList mylist : objUser.getReproductionlist()) {
					if (mylist.getName().equalsIgnoreCase(namePlaylist)) {
						mylist.getAudioList().add(objA);
					}
				}
			} else {
				Premium objUser = (Premium) searchUser(userId);
				for (ReproductionList mylist : objUser.getMyPremiumList()) {
					if (mylist.getName().equalsIgnoreCase(namePlaylist)) {
						mylist.getAudioList().add(objA);
					}
				}
			}
		} else if (editOp == 3) {
			if (objU instanceof Estandar) {
				Estandar objUser = (Estandar) searchUser(userId);
				for (ReproductionList mylist : objUser.getReproductionlist()) {
					if (mylist.getName().equalsIgnoreCase(namePlaylist)) {
						mylist.getAudioList().remove(objA);
					}
				}

			} else {
				Premium objUser = (Premium) searchUser(userId);
				for (ReproductionList mylist : objUser.getMyPremiumList()) {
					if (mylist.getName().equalsIgnoreCase(name)) {
						mylist.getAudioList().remove(objA);
					}
				}
			}
		} else if (editOp == 4) {

		}
		return msg;

	}

	public User searchUser(int consumerid) {
		User msg = myUsers.get(0);
		for (int i = 0; i < myUsers.size(); i++) {
			if (myUsers.get(i) instanceof Consumer) {
				msg = myUsers.get(i);
			}
		}
		return msg;
	}

	public String searchAudio(int userId, int listIndex) {
		String msg = "";
		if (!myUsers.isEmpty()) {
			if (myUsers.get(userId) != null) {
				if (myUsers.get(userId) instanceof Consumer) {
					if (myUsers.get(userId) instanceof Estandar) {
						msg = ((Estandar) myUsers.get(userId)).showSongs();
					} else if (myUsers.get(userId) instanceof Premium) {
						msg = ((Premium) myUsers.get(userId)).showSongs();
					}
				} else if (myUsers.get(userId) instanceof Producer) {
					if (myUsers.get(userId) instanceof Artist) {
						msg = ((Artist) myUsers.get(userId)).showSongs();
					}
				}
			}
		}
		return msg;

	}

	public String editNamePlaylist(int idConsumer, String namePlaylist, String newNamePlaylist) {
		String msg = "new name is succefulled";
		User objU = searchUser(idConsumer);
		if (objU == null) {
			msg = "the user is not created";
		} else {
			if (objU instanceof Estandar) {
				Estandar objUser = (Estandar) searchUser(idConsumer);
				for (ReproductionList playlist : objUser.getReproductionlist()) {
					if (playlist.getName().equalsIgnoreCase(namePlaylist)) {
						playlist.setName(newNamePlaylist);
					}
				}
			} else {
				if (objU instanceof Premium) {
					Premium objUser = (Premium) searchUser(idConsumer);
					for (ReproductionList playlist : objUser.getMyPremiumList()) {
						if (playlist.getName().equalsIgnoreCase(namePlaylist)) {
							playlist.setName(newNamePlaylist);
						}
					}
				}
			}
		}
		return msg;
	}

	public String shareList(int userId, int listIndex) {
		Estandar usr = (Estandar) myUsers.get(userId);
		ReproductionList rl = usr.getReproductionlist()[listIndex];

		String msg = showPlayList(userId);

		return msg;
		switch (option) {
		case 1:
			for (int i = matriz.length; i > 0; i--) {
				code += matriz[i - 1][0];
			}
			for (int i = 1, j = 1; i < matriz.length - 1; i++, j++) {
				code += matriz[i][j];
			}
			for (int i = matriz.length; i > 0; i--) {
				code += matriz[i - 1][matriz[0].length - 1];
			}
			break;

		case 2:
			for (int j = 0; j < matriz.length - 4; j++) {
				code += matriz[0][j];
			}
			for (int i = 0; i < matriz.length; i++) {
				code += matriz[i][2];
			}
			for (int i = matriz.length; i > 0; i--) {
				code += matriz[i - 1][3];
			}
			for (int j = matriz.length - 2; j < matriz.length; j++) {
				code += matriz[0][j];
			}
			break;
		case 3:
			for (int i = 5; i >= 0; i--) {
				for (int j = 5; j >= 0; j--) {
					int sum = i + j;
					if (sum % 2 != 0) {
						if (sum != 1) {
							code += matriz[i][j] + " ";
						}
					}
				}
			}
			break;
		}
		return code;
	}

	public String PlayAudio(int userId, int audioId, int listIndex) {
		Estandar usr = (Estandar) myUsers.get(userId);
		ReproductionList rl = usr.getReproductionlist()[listIndex];
		Premium usr1 = (Premium) myUsers.get(userId);
		ReproductionList rl1 = usr1.getMyPremiumList()[listIndex];

		String msg = showPlayList(userId);
	}

	public String purchaseSong(int songId) {

	}

}
