package model;

public enum ListType {
	SONGS, PODCAST, SONGS_AND_PODCAST
}
